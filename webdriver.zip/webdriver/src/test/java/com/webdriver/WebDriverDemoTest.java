package com.webdriver;

import org.testng.annotations.Test;

public class WebDriverDemoTest {
  @Test
  public void f() {
  }
}
